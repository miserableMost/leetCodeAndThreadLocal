package HuaWeiCode.demo4;

import java.io.*;
import java.util.ArrayList;


public class Main {

    private static ArrayList<String> testdata;
    private static ArrayList<String> resultdata;

    public static void main(String[] args) {



        testdata = new ArrayList<>();
        resultdata = new ArrayList<>();
        //新建一个list

        readFile();

        Method method = new Method();
//        Method1 method = new Method1();
        method.generateGraph(testdata);
        ArrayList<ArrayList<Integer>> lists = method.findLoopPath();


        method.sortByDic(lists);
        writeFile(lists);


    }

    //读测试文件
    private static void readFile(){

        String pathname = "\\data\\test_data.txt";
        try (FileReader reader = new FileReader(pathname);
             BufferedReader br = new BufferedReader(reader))
        {
            String s;
            while ((s = br.readLine()) != null) {
                testdata.add(s);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    private static void writeFile( ArrayList<ArrayList<Integer>> list){
        String path = "\\projects\\student\\result.txt";

        try {
            File file = new File(path);
            file.createNewFile();
            FileWriter fw = new FileWriter(file);
            BufferedWriter out = new BufferedWriter(fw);
            out.write(list.size()+"\r\n");
            for(ArrayList<Integer> li : list){
                if(li.size()<=2) continue;
                for(Integer i : li){
                    out.write(i+",");
                }
                out.write("\r\n");
                out.flush();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }



}
